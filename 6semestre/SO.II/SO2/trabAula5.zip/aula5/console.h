#define CLEAR_SCREEN "\033[2J"
#define CURSOR_UP_LEFT "\033[1;1H" //move cursor para 1;1
#define BOLD "\033[1m"
#define RESET_BOLD "\033[22m"

//color
#define GREEN "\033[38;2;57;255;20m"
#define PINK_BACK "\033[48;2;255;0;255m"
#define PINK "\033[38;2;255;0;255m"
#define PURPLE_BACK "\033[48;2;128;0;128m"
#define WHITE "\033[38;2;255;255;255m"
#define RESET_COLOR "\033[0m"

#define WHITE_BACK "\033[48;2;255;255;255m"