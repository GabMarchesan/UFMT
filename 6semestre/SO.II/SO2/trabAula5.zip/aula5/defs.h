//UART
int uart_getc();
void uart_putc(char c);
void uart_init();

//...