//MMIO mappings

#define UART 0x10000000