//Prova 2 de prog II
// Gabriel Gomes Marchesan

//Bibliotecas
#include <iostream>
#include <vector>

using namespace std;

//-----------Classe Pessoa----------
class Pessoa {

private:
    string nome;
    string cpf;

public:
//construtor
    Pessoa(string n,  string cpf) : nome (n), cpf (cpf) {}

//seletores (get)
    string getNome () {return nome;}
    string getCpf () {return cpf;}


//modificadores(set)
    void setNome (string n) {nome = n;}
    void setCpf (string c) {cpf = c;}

//outros 
    virtual void print() {
        cout << "------------------------" << endl;
        cout << "Nome: " << nome << endl;
        cout << "CPF: " << cpf << endl;
    }
};

//----------Classe Aluno----------- 
class Aluno : public Pessoa {
private:
    int rga;

public:
//construtor
    Aluno (string n, string cpf, int r) : Pessoa (n, cpf), rga(r) {}

//seletores(get)
    int getRga () {return rga;}

//modificadores(set)
    void setRga (int r) {rga = r;}

//Dados
    void print () override {Pessoa :: print();
        cout << "Categoria: Estudante" << endl;
        cout << "RGA: " << rga << endl; 
        cout << "------------------------" << endl;
    }
};

//-----------Classe Professor----------
class Professor : public Pessoa {

private:
    int siape;

public:
//construtor
    Professor(string n, string cpf, int s) : Pessoa (n, cpf), siape(s) {} 
    
//seletores (get)
    float getSiape () {return siape;}

//modificadores(set)
    void setSiape (float s) {siape = s;}

//outros metodos
    void print () override {Pessoa :: print();
        cout << "Categoria: Professor" << endl;
        cout << "SIAPE: " << siape << endl;
        cout << "-----------------------" << endl;
    }
};

int main() {

    Pessoa pe("Joao","123.456.789-00");
    Professor pf1("Jose","012.234.567-89", 2744102);
    Aluno al1("Maria","234.567.890-12", 2020122);
    Professor pf2("Antonio","345.567.789-10", 1740120);
    Aluno al2("Jorge","456.789.012-34", 2721132);

//30% da nota até aqui
    vector<Pessoa*> pp;
    pp.push_back(&pe);
    pp.push_back(&pf1);
    pp.push_back(&al1);
    pp.push_back(&pf2);
    pp.push_back(&al2);

//+ 30% da nota até aqui
    for (auto p : pp){
    p->print();
    }
//+ 30% da nota até aqui
}