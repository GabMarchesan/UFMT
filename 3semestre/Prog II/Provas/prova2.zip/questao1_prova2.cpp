//Prova 2 de prog II 
//questão 1
//Gabriel Gomes Marchesan

//Bibliotecas
#include <iostream>
#include <vector>
#include <memory>

using namespace std;

//
class Compra {
private:
    double valor;
    string local;
    int parcela;
    int data [3];
    int hora [2];

public:  
// construtor(get)
Compra() = default;
Compra(double v, string l, int p ) : valor(v), local(l), parcela(p) {}

//seletor(set)
    double getValor () {return valor;}
    string getLocal () {return local;}
    int getParcela () {return parcela;}
    // int getData () {return data;}
   //  int getHora() {return hora;}

//modificador
    void setValor (double v) {valor = v;}
    void setLocal (string l) {local = l;}
    void setParcela (int p) {parcela = p;}
  //void setData (int d) {data = d;}
   //void setHora (int h) {hora = h;}


//outros métodos

void print() {
    cout << "Compra Realizada " << endl;
    //cout << "Data-Hora: " << data << " - " << hora << endl;
    cout << "Local: " << local << endl; 
    cout << "Valor: " << parcela << "x R$" << (valor / parcela) << endl;
    cout << "---------------------" << endl;
    };

};



//-----------Classe fatura------------
class FaturaCartao {
private:
    vector<Compra> *i;

public:
    FaturaCartao() {i = new vector<Compra>;}
    ~FaturaCartao();

    void add(Compra x);
    void fechaFatura();
    
    
};
// ----------outros-----------

void FaturaCartao :: add(Compra x){
    i->push_back(x);
}

void FaturaCartao :: fechaFatura(){
    float soma = 0;
    string local;
    double valor;

   
    for(auto c : *i){
        c.print();
        
        soma = soma + (c.getValor()/c.getParcela());
        valor = (c.getValor()/c.getParcela());
        local = c.getLocal();
            
    }
     cout << endl << "||    Fatura Fechada     ||" << endl;
        cout << "Total Fatura: R$ " << soma << endl << endl << endl;
}


//---------destruidor---------
FaturaCartao :: ~FaturaCartao() {
    delete i;
}


//---------int main---------

int main() {
    Compra c1;
    Compra c2(100, "Restaurante", 1);
    c1.print();
    c2.print();
//20% da nota até aqui
    c1.setLocal("Oficina");
    c1.setValor(600.0);
    c1.setParcela(3);
   // c1.setData(23,10,2022);
   // c1.setHora(15,45);
    c1.print();
//+ 40% da nota até aqui
    FaturaCartao f;
    f.add(c1);
    f.add(c2);
    Compra c3(700,"Loja",2);
    f.add(c3);
    f.fechaFatura();
//+ 40% da nota até aqui

}
