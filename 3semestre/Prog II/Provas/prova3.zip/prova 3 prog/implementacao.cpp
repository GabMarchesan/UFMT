//Implementação PontoCartesiano

//Bibliotecas 
#include <iostream>
#include <string>

#include "PontoCartesiano.h"

//Using Namespace
using std::cout;
using std::cin;
using std::endl;
using std::string;

//Função Imprime 
void imprime(){
    cout << "("<< getX() << "," << getY() << ")" << endl;
}

//operador+
PontoCartesiano operator+(PontoCartesiano &lop, PontoCartesiano &rop){
    PontoCartesiano test(0,0);
    test.X = lop.X + rop.X;
    test.Y = lop.Y + rop.Y;
    
    return test;
}