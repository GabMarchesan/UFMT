//Prova 3 de Prog II
//Gabriel Gomes Marchesan

//Bibliotecas
#include <string>
#include <iostream>

#include "PontoCartesiano.h"

//using namespace
using std::cout;
using std::cin;
using std::endl;
using std::string;

//Int main
int main(){

    PontoCartesiano<int> p1(2,2);
    PontoCartesiano<int> p2(3,3);
    auto p3 = p1 + p2;
    p3.imprime(); //(5,5)


    //Erro quando for (0,0)
    try{
        PontoCartesiano<int> p4(0,0); 

    } catch (invalid_argument e) {
        cout<< e.what();
    }

}