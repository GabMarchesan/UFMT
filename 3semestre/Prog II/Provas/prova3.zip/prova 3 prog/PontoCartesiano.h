//Bibliotecas 
#include <string>
#include <iostream>

//Using namespace
using std::cout;
using std::cin;
using std::endl;
using std::string;

//Namespace Prova 3 
namespace Prova3{

template <typename U, typename T>
//Classe Ponto Cartesiano 
    class PontoCartesiano{
        private:
            U X;
            T Y;
        public:

            //construtor
            PontoCartesiano(T pontoY, U pontoX){
                if (pontoY == 0 & pontoX == 0){
                    throw PontoZero (" ERRO, Pois nao existe coordenada (0,0)");
                }

            pontoY = Y;
            pontoX = X; 

            }
            
            //Gets
            T getY() const { return Y;}
            U getX() const { return X;}

            //Método imprime
            void imprime(){}

            //Função do operador+
            friend PontoCartesiano operator+(PontoCartesiano &lop, PontoCartesiano &rop);

    };
}

//Classe exception chamada PontoZero que herde da exceção invalid_argument
class PontoZero : public std::invalid_argument{
    public:  
        PontoZero (string message) : std::invalid_argument(message){}

};