#include <iostream>
#include <vector>
#include <memory>

using namespace std;

vector <int>* create(){
    vector <int> *p1 = new vector <int>;
    return p1;

}

void insert(vector <int> *p1, int value){
    p1 -> push_back(value);  
}

void imprime(vector <int> *p2){
    for (auto g : *p2){
    cout << g << endl;
    }
}

int main(){

    auto a = create();
    insert(a,52);
    imprime(a);
    delete a;
}