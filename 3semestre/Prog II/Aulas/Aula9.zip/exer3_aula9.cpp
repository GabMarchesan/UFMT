#include <iostream>
#include <string>
#include "loja.h"
#include "mercado.h"

using std::string;
using std::cin;
using std::cout;
using std::endl;

void loja::faturar(mercado::Compra &c, loja::Compra &d){
    int total = c.total + d.total;
    cout << total << endl;
}

int main(){
    mercado::Compra c1(2,9);
    loja::Compra c2(2,9);

    cout << "O total da fatura eh: " << endl;
    mercado::faturar(c1,c2);
}