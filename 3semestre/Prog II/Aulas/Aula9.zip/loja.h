#ifndef loja_h
#define loja_h

namespace mercado {
    class Compra;
}

namespace loja {
    class Compra {
        private:
            int qtdItens;
            int valorCompra;
        public:
            Compra(int qtdItens, int valorCompra) : qtdItens(qtdItens), valorCompra(valorCompra) {}

            int getQtdItens() { return qtdItens; }
            int getValorCompra() { return valorCompra; }

            int total() {
                int total = getQtdItens() * getValorCompra();
                return total;
            }

            friend void faturar( mercado::Compra &c );
    
};
}

#endif 
   
    