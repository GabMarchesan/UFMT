#include <iostream>
#include <string>

using std::string;
using std::cout;
using std::endl;

namespace A{
    namespace B{
        int mult (int a, int b); 
    }
}

int A :: B :: mult (int a, int b){
    int m = a * b;
        cout << m << endl;
        return m;
}

int main(){
    namespace AB = A::B ;

    AB::mult(3,7);
}