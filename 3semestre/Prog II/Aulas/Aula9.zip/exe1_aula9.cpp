#include <iostream>
#include <string>

using std::string;
using std::cout;
using std::endl;

namespace x{
    int soma(int x, int y){
        int soma = x + y;
        cout << soma << endl;
        return soma;
    }
}
namespace y{
    int soma(int a, int b){
        int soma = a + b;
        cout << soma << endl;
        return soma;
    }
}

int main(){
    int x = 10;
    int y = 11;
    int a = 12;
    int b = 13;

x::soma(x,y);
y::soma(a,b);

cout << x::soma(x,y) + y::soma(a,b) << endl;
}


