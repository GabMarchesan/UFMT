#ifndef mercado_h
#define mercado_h

#include "loja.h"

namespace mercado {
    class Compra{
        private:
             int qtdItens;
             int valorCompra;
        public:
             Compra(int qtdItens, int valorCompra) : qtdItens(qtdItens), valorCompra(valorCompra) {}

             int getQtdItens() { return qtdItens; }
             int getValorCompra() { return valorCompra; }

             friend void loja::faturar(Compra &c, loja::Compra &d);
             
             int total() {
                int total = getQtdItens() * getValorCompra();
                return total;
            }
              
    };
}

#endif