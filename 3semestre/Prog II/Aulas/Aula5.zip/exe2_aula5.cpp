#include <iostream>
#include <vector>
#include <memory>

using namespace std;

class Itemfatura{
    private:
    int id;
    string nome;
    int qtd;
    float precoUnit;

    public:

    Itemfatura() = default;
    Itemfatura(int i, string n, int q, float p) : id(i), nome(n), qtd(q), precoUnit(p){};

    //metodos seletor
    int getId();
    string getNome();
    int getQtd();
    float getPrecoUnit();

    //metodos modificador
    void setId(int);
    void setNome(string);
    void setQtd(int);
    void setPrecoUnit(float);

    float totalItem();
    void imprime();

};

int Itemfatura::getId(){
    return id;
}

string Itemfatura::getNome(){
    return nome;
}

int Itemfatura::getQtd(){
    return qtd;
}

float Itemfatura::getPrecoUnit(){
    return precoUnit;
}

void Itemfatura::setId(int i){
    id = i;
}

void Itemfatura::setNome(string n){
    nome = n;
}

void Itemfatura::setQtd(int q){
    qtd = q;
}

void Itemfatura::setPrecoUnit(float p){
    precoUnit = p;
}

float Itemfatura :: totalItem(){
    return precoUnit* qtd;
}
void Itemfatura::imprime(){
    cout << "Id: " << id << endl;
    cout << "Nome: " << nome << endl;
    cout << "Qtd: " << qtd << endl;
    cout << "Preco Unitario: " << precoUnit << endl << endl;
};



class Fatura {
private:
    vector<Itemfatura> *v;

public:
    Fatura() {v = new vector<Itemfatura>;}
    ~Fatura(){delete v;}

    void addItem(Itemfatura x);
    void totalFatura();
};



void Fatura :: addItem(Itemfatura x){
    v->push_back(x);
}

void Fatura::totalFatura(){
    float somatotal = 0.0;
    for(auto c : *v){
        c.imprime();
         somatotal = somatotal + c.totalItem() ;;
    }
     cout << "Valor total da fatura : " << somatotal << endl;
}


    


int main(){


    Itemfatura item1 = Itemfatura();
    Itemfatura item2(10101010, "Coca", 5, 2);
    Itemfatura item3(12121212, "fanta", 8, 10);
    Fatura v;


    v.addItem(item1);
    v.addItem(item2);
    v.addItem(item3);

    v.totalFatura();

}