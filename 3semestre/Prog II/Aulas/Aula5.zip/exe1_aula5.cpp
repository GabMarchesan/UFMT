#include <iostream>

using namespace std;

class Itemfatura{
    private:
    int id;
    string nome;
    int qtd;
    float precoUnit;

    public:

    Itemfatura() = default;
    Itemfatura(int i, string n, int q, float p) : id(i), nome(n), qtd(q), precoUnit(p){};

    //metodos seletor
    int getId();
    string getNome();
    int getQtd();
    float getPrecoUnit();

    //metodos modificador
    void setId(int);
    void setNome(string);
    void setQtd(int);
    void setPrecoUnit(float);

    float totalItem();
    void imprime();

};

int Itemfatura::getId(){
    return id;
}

string Itemfatura::getNome(){
    return nome;
}

int Itemfatura::getQtd(){
    return qtd;
}

float Itemfatura::getPrecoUnit(){
    return precoUnit;
}

void Itemfatura::setId(int i){
    id = i;
}

void Itemfatura::setNome(string n){
    nome = n;
}

void Itemfatura::setQtd(int q){
    qtd = q;
}

void Itemfatura::setPrecoUnit(float p){
    precoUnit = p;
}

float Itemfatura :: totalItem(){
    return precoUnit* qtd;
}
void Itemfatura::imprime(){
    cout << "Id: " << id << endl;
    cout << "Nome: " << nome << endl;
    cout << "Qtd: " << qtd << endl;
    cout << "Preco Unitario: " << precoUnit << endl << endl;
};

int main(){

    Itemfatura p1 = Itemfatura();
    Itemfatura p2(19022002, "Coca", 5, 8);

    p1.imprime();
    p2.imprime();
    
    p1.setId(9);
    p1.setNome("fanta");
    p1.setQtd(5);
    p1.setPrecoUnit(10);
    p1.imprime();

    p2.setPrecoUnit(15);
    p2.imprime();

}

