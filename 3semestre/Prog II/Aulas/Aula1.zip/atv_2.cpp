// exercicio 2

#include <iostream>
using namespace std;

int main()
{

    int a, b;
    float c;
    cout << "Informe o valor em Fahrenheit: " << endl;
    cin >> a;
    b = a - 32;
    c = b * 5 / 9;

    cout << "O equivalente de " << a << "Em Celsius é " << c << endl;

    return 0;
}