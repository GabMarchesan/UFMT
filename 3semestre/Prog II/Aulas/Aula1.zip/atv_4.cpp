// exercicio 4

#include <iostream>
using namespace std;

bool par (int x){
    if (x % 2 == 0 && x != 0){ 
            return true;
    } else {
            return false;
      }

}

int main()
{
    int v[10];

    cout << "Insira 10 valores : \n";

    for (int i = 0; i < 10; i++)
    {
        cin >> v[i];
    }

    for (int i = 0; i < 10; i++)
    {
        if (v[i] % 2 == 0 && v[i] != 0)
        {
            cout << "Valores pares do vetor sao: " << v[i] << endl;
        }
    }

    return 0;
}