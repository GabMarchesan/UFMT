// exercicio 1

#include <iostream>

using namespace std;

int main()
{

    int a, b;
    cout << "informe valor para A:\n ";
    cin >> a;

    cout << "Informe valor para B:\n ";
    cin >> b;

    if (a == b)
    {
        cout << "Erro, sao iguais";
    }

    if (a > b)
    {
        cout << "O maior numero e: " << a << endl;
    }

    else
    {
        cout << "O maior numero e: " << b << endl;
    }

    return 0;
}