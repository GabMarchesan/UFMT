#include <iostream>

using namespace std;

int somatorio(int a[], int tamanho){ //recursão, vetor inteiro 
   if (tamanho == 1) {
   return a[0];
   }
   return a[tamanho-1] + somatorio(a,tamanho-1);
   
}
 
 int main()
 {
   cout << "Digite a quantidade de numeros a ser colocado:" <<endl;
    int n, media, soma;
  //a quantidade de números

     cout << "Insira um numero: " << endl;
     cin >> n;

     int v[n];

 //os valores que o usuario coloca
     cout << "Insira " << n << " Valores: " << endl;

        for (int i = 0 ; i < n; i++) //loomping 
          cin >> v [i];
 

   soma = somatorio(v, n);
   media = soma/n;

   cout << "A soma dos valores e: " << soma <<endl << "A media dos valores e: " << media <<endl;

}
