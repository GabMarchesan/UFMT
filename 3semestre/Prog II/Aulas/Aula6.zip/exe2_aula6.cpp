#include <iostream>
#include <cmath>
#include <vector>
using namespace std;

class ObjetoGeometrico {

private:

public:

    //outros métodos
    virtual void MostraArea() = 0;
    virtual void MostraPerimetro () = 0;

};


class circulo : public ObjetoGeometrico {

private:
    int raio;

public:
    
    //contrutor
    circulo (int raio) :  raio (raio) {}

    //seletor (get)
    int GetRaio () {return raio;}

    //modificadores (set)
    void SetRaio (int raio) {raio = raio;}

    //outros métodos
    void MostraArea () override {
        int a = 3.14 * GetRaio();
        cout << "A area do circulo eh: " << a << endl;
    }

    void MostraPerimetro () override {
        int p = 2 * 3.14 * GetRaio() ;
        cout << "O perimetro do circulo eh: " << p << endl << endl;
    }

};


class Retangulo : public ObjetoGeometrico {

private:
    int base;
    int altura;

public:
   
    //contrutor
    Retangulo (int base, int altura) :  base (base), altura(altura) {}

    //seletor (get)
    int GetBase () {return base;}
    int GetAltura () {return altura;}

    //modificadores (set)
    void SetBase (int base) {base = base;}
    void SetAltura (int altura) {altura = altura;}

        //outros métodos
    void MostraArea () override{ 
        int a = GetBase() * GetAltura();
        cout << "A area do retangulo eh: " << a << endl;
    }

    void MostraPerimetro () override { 
        int p = (2 * GetBase()) + (2 * GetAltura());
        cout << "O perimetro do retangulo eh: " << p << endl << endl;
    }
};


class Triangulo : public ObjetoGeometrico {

private:
    int lado1;
    int lado2;
    int lado3;

public:

    //contrutor
    Triangulo (int L1, int L2, int L3) : lado1(L1), lado2(L2), lado3(L3) {}

    //seletores (get)
    int GetLado1 () {return lado1;}
    int GetLado2 () {return lado2;}
    int GetLado3 () {return lado3;}

    //modifcadores (set)
    void SetLado1 (int lado1) {lado1 = lado1;}
    void SetLado2 (int lado2) {lado2 = lado2;}
    void SetLado3 (int lado3) {lado3 = lado3;}

    //outros métodos
    void MostraArea () override { 
        int s = (GetLado1() + GetLado2() + GetLado3())/2;
        int a = sqrt(s * (s - GetLado1()) * (s - GetLado2()) * (s - GetLado3()));
        cout << "A area do triangulo eh: " << a << endl;
    }

    void MostraPerimetro () override { 
        int p = GetLado1() + GetLado2() + GetLado3();
        cout << "O perimetro do triangulo eh: " << p << endl << endl;
    }
};


int main (){

    vector <ObjetoGeometrico*> f; 

    circulo c (7);
    Retangulo r (4,5);
    Triangulo t (3,4,5);

    f.push_back(&c);
    f.push_back(&r);
    f.push_back(&t);
    
    for (auto z : f){
        z -> MostraArea();
        z -> MostraPerimetro();
    }
}