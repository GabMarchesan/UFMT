#include <iostream>
#include <vector>

using namespace std;
class VeiculoAVenda{
    private:
       string marca;
       string modelo;
       int ano;
       float precoDeVenda;
    public:

    //Construtor
       VeiculoAVenda(string m, string mo, int a, float p) : marca(m), modelo(mo), ano(a), precoDeVenda(p){};
    
    //seletor(get)
    string getMarca() {return marca;}
    string getModelo() {return modelo;}
    int getAno() {return ano;}
    float getPrecoDeVenda() {return precoDeVenda;}
    
    //modificador(set) sempre void
    void setMarca(string m){marca = m;}
    void setModelo(string mo){modelo = mo;}
    void setAno(int a){ano = a;}
    void setPrecoDeVenda(float p){precoDeVenda = p;}

    //outros métodos
    virtual void mostraDados(){
      cout << " marca: " << marca << endl;
      cout << " modelo: " << modelo << endl;
      cout << " ano: " << ano << endl;
      cout << " Preco do veiculo " << precoDeVenda << " reais " << endl;
    }
       
};

class AutomovelAVenda : public VeiculoAVenda{
   private:
       float motor;
       bool cambio;
       int numeroDePortas;

   public:
       
   //construtor
       AutomovelAVenda(string m, string mo, int a, float p, float mot, bool cam, int num) : VeiculoAVenda (m, mo, a, p), motor(mot), cambio(cam), numeroDePortas(num){};

   //seletor(get)
       float getMotor(){return motor;}
       bool getCambio(){return cambio;}
       int getNumeroDePortas(){return numeroDePortas;}

   //modificador(set)
       void setMotor(float mot){motor = mot;}
       void setCambio(bool cam){cambio = cam;}
       void setNumeroDePortas(int num){numeroDePortas = num;}

   //outro metodo
         void mostraDados() override { VeiculoAVenda :: mostraDados();
         cout << " Motor: " << motor << endl;
         if(cambio == true){
            cout << " cambio : manual " << endl; 
         }else{
            cout << " Cambio : automatico " << endl;
         }
         cout << " portas: " << numeroDePortas << endl;
         }

};

class MotocicletaAVenda : public VeiculoAVenda{
   private:
       int cilindradaDoMotor;
   public:

   //construtor
   MotocicletaAVenda(string m, string mo, int a, float p, int ci) : VeiculoAVenda (m, mo, a, p), cilindradaDoMotor(ci){};

   //seletor(get)
   int getCilindradaDoMotor(){return cilindradaDoMotor;}

   //modificador(set)
   void setCilindradaDoMotor(int ci){cilindradaDoMotor = ci;}

   //outro metodo
   void mostraDados() override { VeiculoAVenda :: mostraDados();
   cout << " cilindrada do motor:  " << cilindradaDoMotor << endl;
   }
};

int main(){

   cout << endl;
   vector<VeiculoAVenda* > v;

   AutomovelAVenda carro("Nissan","Versa", 2020, 60000, 1.6, false, 5 );
   MotocicletaAVenda m("Honda", "Fan", 2022, 13900, 160);

   double p;

   v.push_back(&carro);
   v.push_back(&m);

   for (auto z : v){
      z -> mostraDados();
      p = p + z -> getPrecoDeVenda();
   }
     cout << " total eh: " << p << endl;
}