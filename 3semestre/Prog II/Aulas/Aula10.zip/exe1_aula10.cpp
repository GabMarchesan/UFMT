#include <iostream>

using namespace std;

class HourException : public std:: out_of_range{
public:
HourException(std::string message) : std::out_of_range(message) {}
};

class MinutesException : public std:: out_of_range{
public:
MinutesException(std::string message) : std::out_of_range(message) {}
};

class SecondsException : public std:: out_of_range{
public:
SecondsException(std::string message) : std::out_of_range(message) {}
};

class Tempo{
    private:
        int hora; 
        int minuto; 
        int segundo;
    
    public:

    Tempo(): hora(00), minuto(00), segundo(00){};

    Tempo(int h, int m, int s) {try {
      if ( hora > 23 || hora < 0 ){
        throw HourException("Ops! Voce nao pode colocar uma hora negativa ou superior a 23. ") ;
      } if(minuto < 0 || minuto > 59){
          throw MinutesException("Ops! Voce nao pode colocar um minuto negativo ou superior a 59. ") ;
      }
      if(segundo < 0 || segundo > 59){
          throw SecondsException("Ops! Voce nao pode colocar um segundo negativo ou superior a 59. ") ;
      }
      
      hora=h;
      minuto=m;
      segundo=s;
      }
    catch(out_of_range e){
   cout << "Algo deu errado :( " << endl;
    cout << e.what() << "\n" ;
    exit(1);
      
     
    }
      };
  
    void setHora(int h){hora = h;}
    void setMinuto(int m){minuto = m;}
    void setSegundo(int s){segundo = s;}

    int getHora(){return hora;}
    int getMinuto(){return minuto;}
    int getSegundo(){return segundo;}
    void imprime(){
                cout << getHora() << ":"<< getMinuto()<< ":"<< getSegundo()<< endl;

    }
    };

int main(){

    Tempo first(-1,10,50);
}