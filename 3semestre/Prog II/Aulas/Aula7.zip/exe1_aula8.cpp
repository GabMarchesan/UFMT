//bibliotecas 

#include <iostream>
#include <string>

using namespace std;

//Classe Data

class Data{
private:
    int dia, mes, ano;
public:
    Data(int d, int m, int a) : dia(d), mes(m), ano(a) {}


    friend bool operator==(Data &cal1, Data &cal2);
    friend void operator++(Data &cal);
    friend void operator+(Data &cal, int var);
    friend void operator+=( Data &date, int var1);
    friend std::istream &operator>>(std::istream &is, Data &cal);
    friend std::ostream &operator<<(std::ostream &os,const Data &cal);
    
    
    void setDia(int d){dia = d;}
    void setMes(int m){mes = m;}
    void setAno(int a){ano = a;}

    int getDia(){return dia;}
    int getMes(){return mes;}
    int getAno(){return ano;}

 int ultimoDiaMes(){
        int ultimo_dia;
        if (getMes() == 1 || getMes()== 3|| getMes() == 5|| getMes() == 7|| getMes() == 8|| getMes() == 10|| getMes() == 12){
            return ultimo_dia = 31;
        }else if( getMes() == 4|| getMes() == 6|| getMes() == 9|| getMes() == 11){
            return ultimo_dia = 30;
        }else if(getMes() == 2){
           if ((getAno() % 400 == 0) || (getAno() % 4 == 0) && (getAno() % 100 != 0) ) {

            return ultimo_dia = 29;

           }
           
           else{
            return ultimo_dia = 28;
           }
        }
     
    }

//Imprime 
void imprime(){
        cout << getDia() << "/"<< getMes()<< "/"<< getAno()<< endl;

    }
    
};

bool operator==(Data &cal1, Data &cal2){
    return cal1.getDia() == cal2.getDia() && cal1.getMes() == cal2.getMes() && cal1.getAno();}

void operator++(Data &cal){
    if( cal.getDia() == cal.ultimoDiaMes()){
        cal.setDia(1);
        if(cal.getMes()+1 >= 12){
            cal.setMes(1);
            cal.setAno(cal.getAno()+1);

        } else{
            cal.setMes(cal.getMes()+1);
        }

    }else{
        cal.setDia(cal.getDia()+1);

    }
    
}

void operator+(Data &cal, int var){
    cal.setDia(cal.getDia()+var);
    while ( cal.getDia() > cal.ultimoDiaMes()){
        cal.setDia(cal.getDia()- cal.ultimoDiaMes());
        if(cal.getMes() >= 12){
            cal.setMes(1);
            cal.setAno(cal.getAno()+1);

        }else{
            cal.setMes(cal.getMes()+1);
        }
    }
}
void operator+=( Data &date, int var1){
    operator+(date,var1 );

}
std::istream &operator>>(std::istream &is, Data &cal){
    cout << " Digite uma data __/__/____"<< endl;
    is >> cal.dia >> cal.mes>> cal.ano;
    if(is){

    }
    return is;

}
std::ostream &operator<<(std::ostream &os,const Data &cal){
    os << cal.dia<< "/"<< cal.mes<<"/"<<cal.ano;
    return os;
}

//int main
int main(){

    Data cal1(19,02,2020);
    Data cal2(24,12,2019);

   

    //operador ==
    cal1.imprime();
    cal1==cal2;
    
    //operador ++

    ++cal1;
    cal1.imprime();

    //operador +
    cal1+365;
    cal1.imprime();

    for(int i = 0; i < 10;i++){
        cal1+=1;
    }
    cal1.imprime();

    std::cin >> cal1;

    std::cout << cal1;

}

