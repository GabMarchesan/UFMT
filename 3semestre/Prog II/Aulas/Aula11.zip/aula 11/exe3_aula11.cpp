#include <iostream>
using namespace std;

template <typename T, typename U>
class Pair {
private:
    T first;
    U second;
public:
    Pair(const T& t, const U& u) : first(t), second(u) {}
    T& get_first() { return first; }
    U& get_second() { return second; }
    const T& get_first() const { return first; }
    const U& get_second() const { return second; }
    void print_pair (){
        cout << "Os pares sao: " << first << " e " << second << endl; 
    }
    void add_pair (){
        
        auto x = first + second;
        cout << x << endl;
    }

};


int main () {
    string a = "Pato";
    string b = "Cobra";

    Pair<string,string> x (a,b);

    x.print_pair();
    x.add_pair();

}