#include <iostream>

using namespace std;

template <typename T>
T maximum(const T &a, const T &b){
    if (a > b) return a;
    if (b > a) return b;
    return 0;
};


int main (){

    string a = "Pato";
    string b = "Cobra";

    cout << "A maior variavel eh: " << endl;
    cout << maximum(a,b) << endl;


    cout << "O valor eh: " << endl;
    auto res = maximum(a,b);
    cout << res << endl;
    
}