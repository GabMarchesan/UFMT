#include <iostream>
using namespace std;

template <typename T, typename U>
void troca(T &a, U &b){
    T aux = a;
    a = b;
    b = aux;

    cout << "Os novos valores sao: " << a << " e " << b << endl;
};


int main (){

    string a = "Pato" ;
    string b = "Cobra";

    troca(a,b);

}