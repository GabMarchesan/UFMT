#include <iostream>
#include <string>

using namespace std;
int main(){
    string line;
    int x;
    cout << " Digite uma frase: ";
    getline(cin, line);
    for(auto x: line){
        if(!isspace(x)){
            cout << x;
        }
    }
}