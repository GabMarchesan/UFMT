
#include <iostream>
#include <string>

using namespace std;

using std::string;

void troca (int *x, int *y){
    int temporario;
    temporario = *x;
    *x = *y;
    *y = temporario;
}

int main(){
    int a, b;
 cout << "digite os valores a serem trocados: " << endl;
 cin >> a >> b;

cout << " Os valores " << a << " e " << b << " se tornaram ";

troca(&a,&b);

cout << a << " e " << b << ", respectivamente. " << endl;
}