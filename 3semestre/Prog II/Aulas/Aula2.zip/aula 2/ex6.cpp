#include <iostream>
#include <string>

using namespace std;

struct retangulo {
    int  altura, largura; 
};

int area(retangulo ret){
    int produto;
    produto = ret.altura * ret.largura;

    return produto; 
}

int main(){
     retangulo retan;
     cout << " digite a altura: ";
     cin >> retan.altura;
     cout << " Digite a largura: ";
     cin >> retan.largura;

     cout << area(retan);
}