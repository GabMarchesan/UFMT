#include <iostream>
#include <memory>
#include <vector>

using namespace std;
unique_ptr<vector<int>> create_unique(){
    unique_ptr<vector<int>> g;
    return g;
}


shared_ptr<vector<int>> create(){
   auto a =make_shared <vector<int>>();
return a;
}

void insert(weak_ptr <vector<int>> g, int valor){
    if (auto b = g.lock())
    b->push_back(valor);
}

void imprime(weak_ptr <vector<int>> g){
    if (auto b = g.lock())
     for (auto r : *b)
        cout << r <<endl;
    }
int main(){
   auto i = create();
    insert(i, 52);
    imprime(i);
    unique_ptr<vector<int>> g(create_unique());
    
}