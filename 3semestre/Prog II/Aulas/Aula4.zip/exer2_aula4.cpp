#include <iostream>
using namespace std;


class lampada{
public:
    bool ligada;
    int tipo; //incandescente = 1, led = 2 ou fluorescente = 3
    int watt;
    int cor; //amarela = 1, branca = 2, outros 3
    string marca;

    void ligar(){
        ligada = true;
    }
    void desligar(){
        ligada = false;
    }
    
    
    bool ehEconomica(){
        if (watt < 40)
        return true;

        else 
        return false;
    }

    void status(){
        if (ligada)
        cout << "A lampada " << marca << " esta ligada e ";
        else 
        cout << "A lampada " << marca << " esta desligada e ";

        if (ehEconomica()) {
        cout << "eh economica " << endl;
        } else {
        cout <<"nao eh economica " << endl;
        }
    }

};

int main(){

    lampada l1, l2;

    l1.marca = "Biia";
    l2.marca = "Lucas";

    cout << "Insira a potencia da lampada Biia: " << endl;
    cin >> l1.watt;

    cout << "insira a potencia da lampada Lucas: " << endl;
    cin >> l2.watt;

    l1.ligar();
    l2.desligar();

    l1.status();
    l2.status();

}
