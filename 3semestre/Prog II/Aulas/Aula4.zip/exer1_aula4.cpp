#include <iostream>

using namespace std;

class triangulo{
public:
     float base;
     float altura;

     float CalculaArea(){
        return (base*altura)/2;
    }
};

int main() {
    triangulo t1;

    cout << "Insira o valor da Base: " << endl;
    cin >> t1.base;

    cout << "Insira o valor da Altura: " << endl;
    cin >> t1.altura;

    cout << "A area eh: " << endl;
    cout << t1.CalculaArea();
}