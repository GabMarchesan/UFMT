#include <iostream>
using namespace std;

class empregado{
public:
    string nome;
    float salario;

 void mostraDados(){
    cout << "O empregado " << nome << " recebe um salario de: " << salario << endl;
    }
    float aumento(float porcentagem){
       salario = salario + ((porcentagem/100)*salario);  
    }

   
};

int main(){
    empregado funcionario;
    float porcentagem;

    cout << "Insira o nome do funcionario que recebera o aumento: " << endl;
    cin >> funcionario.nome;

    cout << "Insira o salario atual de " << funcionario.nome << endl;
    cin >> funcionario.salario;

    cout << "Insira a porcentagem de aumento do funcionario: " << endl;
    cin >> porcentagem;

    funcionario.mostraDados();
    funcionario.aumento(porcentagem);
    funcionario.mostraDados();



}

