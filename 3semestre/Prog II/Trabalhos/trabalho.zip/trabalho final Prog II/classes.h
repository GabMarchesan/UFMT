//Bibliotecas
#ifndef trabalho
#define trabalho
#include <string>
#include <iostream>

//Using namespace
using std::endl;
using std::cout;
using std::string;

//Namespace Trabalho
namespace Trabalho{

    //Classe transporte
    class Transporte{
        private:
             string nome;
             int numPassageiros;
             int velocidadeAtual;
        public:
        Transporte();
        Transporte(string no; int nupg, int vlat);

        //Gets
        string getNome();
        int getNumPassageiros();
        int getVelocidadeAtual();

        //Sets
        void setNome(string nome);
        void setNome(int numPg);
        void setVelocidadeAtual(int veloA);

        //Mais Metodos
        friend void operator> (Transporte &lop, Transporte &rop);
        virtual bool estaParado() = 0;
    };

    //Classe Transporte aereo
    class Aereo : public Transporte{
        private:
            int altura;
        public: 
        Aereo();
        Aereo(string no; int nupg, int vlat, int altura);

        //Get
        int getAltura();

        //Set
        void setAltura(int altura);

        //mais metodos
        virtual void subir(int metros) = 0;
        virtual void descer(int metros) = 0;
        bool estaParado() override;


    };
    // Classe transporte terrestre 
    class Terrestre : public Transporte{
        private:

        public:
        Terrestre();
        Terrestre(string no; int nupg, int vlat);

        //mais metodos
        virtual void frear() = 0;
        bool estaParado() override;
    };

    //Classe transporte terrestre carro
    class Carro : public Terrestre{
        private:
        public:

        Carro();
        Carro(string no; int nupg, int vlat);

        //mais metodos
        void frear()override;
    };

//Classe Transporte Aereo aviao
class Aereo : public Aereo {
    private:
    public: 

    aviao();
    aviao(string no; int nupg, int vlat, int alt);

    //mais metodos
    void subir(int metros) override;
    void descer(int metros) override;

};

//Classe transporte aereo balao
class balao : public Aereo{
    private:
    public:

    balao();
    balao(string no; int nupg, int vlat, int alt);

    //mais metodos
    void subir(int metros) override;
    void descer(int metros) override;
};
}

#endif

