//funcoes da Classes transporte
#include "classes.h"

namespace Trabalho{
    Transporte::Transporte() = default;
    Transporte::Transporte(string no, int nupg, int vlat){
        no = nome;
        nupg = numPassageiros;
        vlat = velocidadeAtual;
    }

//Gets
string Transporte:: getNome() { return nome;}
int Transporte:: getNumPassageiros() { return numPassageiros; }
int Transporte:: getVelocidadeAtual() { return velocidadeAtual;}

//Sets
void Transporte:: setNome(string no) { no = nome; }
void Transporte:: setNumPassageiros(int nupg) { nupg = numPassageiros; }
void Transporte:: setVelocidadeAtual(int vlat) { vlat = velocidadeAtual;}

//operador 
void operator>(Transporte &lop, Transporte &rop) {   
    if (lop.getNumPassageiros() > rop.getNumPassageiros()) {
        cout << " O " << lop.getNome() << " Ha mais passageiros que " << rop.getNome() <<endl;
    } else if (rop.getNumPassageiros() > lop.getNumPassageiros()) {
        cout << " O " << rop.getNome() << " Ha mais passageiros que " << lop.getNome() << endl;
    } else {
        cout << lop.getNome() << "pouca quantidade de passageiros!" << endl;
    }
}
// Funcoes da Classe aereo
Aereo::Aereo() = default;
Aereo::Aereo(string no, int nupg, int vlat, int Altura) : Transporte(no, nupg, vlat){
    altura = Altura;
}

//Gets
int Aereo :: getAltura(){ return altura;}

//Sets
void Aereo :: setAltura(int alt){altura = alt;}

//funcao parada 
bool Aereo :: estaParado(){
    if (getVelocidadeAtual() == 0){
        cout << "Ele esta parado" << endl;
        return true;
    } else {
        cout << "Ele nao esta parado" << endl;
        return false;
    }
}  

//funcao do balao

balao::balao() = default;
balao::balao(std::string no, int nupg, int vlat, int Altura) : Aereo(no, nupg, vlat, Alt) {}

//funcao subir
void balao :: subir(int metros){;

    int x = getAltura() + metros;

    if (getAltura() < 1000){
        if(x < 1000){
            setAltura(x);
        }else{
            cout << "Nao e possivel subir mais que 1000 metros" << endl;
        }
    } else {
        cout << "Nao e possivel subir mais que 1000 metros" << endl;
    }
}  

//funcao descer
void balao::descer(int metros) {

    int x = getAltura() - metros;

    if (x == 0 || x < 0) {
        cout << "Nao e possivel descer, pois havera colisao" << endl;
    } else {
        setAltura(x);
        }
    }


//funcao aviao

aviao::aviao() = default;
aviao::aviao(string no, int nupg, int vlat, int Alt) : Aereo(no, nupg, vlat, Alt) {}

//funcao subir    
void aviao :: subir(int metros){;

    int x = getAltura() + metros;

    if (getAltura() < 10000){
        if(x < 10000){
            setAltura(x);
        }else{
            cout << "Nao e possivel subir mais que 10000 metros" << endl;
        }
    } else {
        cout << "Nao e possivel subir mais que 10000 metros" << endl;
    }
}

//funcao descer
void aviao::descer(int metros) {

    int x = getAltura() - metros;
    
    if (x == 0 || x < 0) {
        cout << "Nao eh possivel descer, pois havera colisao" << endl;
    } else {
        setAltura(x);
    }
}



//funcao terrestre
Terrestre::Terrestre() = default;
Terrestre::Terrestre(std::string np, int nupg, int vlat) : Transporte(no, nupg, vlat){}

//funcao esta parada de Terrestre
bool Terrestre :: estaParado(){
    if (getVelocidadeAtual() == 0){
        cout << "Esta parado" << endl;
        return true;
    } else {
        cout << "Nao esta parado" << endl;
        return false;
    }
}


//Funcao de carro

Carro::Carro() = default;
Carro::Carro(std::string no, int nump, int vlat) : Terrestre(no, nump, vlat) {}


//funcao freae de carro
void  Carro :: frear(){
    int x = getVelocidadeAtual() - (getVelocidadeAtual() * 0,25);

    if (getVelocidadeAtual() == 0){
        cout << "O carro ja esta parado" << endl;
        } else {
            setVelocidadeAtual(getVelocidadeAtual() - x);
            cout << "A velocidade atual eh " << getVelocidadeAtual() << endl;
        }
}
}

