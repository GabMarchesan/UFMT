#include <iostream>
#include <string>
#include "classes.h"

using std::string;
using std::cout;
using std::endl;


//INT MAIN
int main(){

//criação de carro, aviao e balao
Trabalho::Carro c ("Versa",4,40);
Trabalho::aviao a ("tam",30,100,8000);
Trabalho::balao b ("Balaozao",7,10, 300);
    
cout << "testar carro" << endl;
cout << "Nome: " << c.getNome() << endl;
cout << "Numero de Passageiros: " << c.getNumPassageiros() << endl;
cout << "Velocidade Inicial: "<< c.getVelocidadeAtual() << endl;
c.frear();
cout << "Velocidade depois do freio: "<< c.getVelocidadeAtual() << endl << endl;


cout << "======================================" << endl << endl;


cout << "testando aviao" << endl;
cout << "Nome: " << a.getNome() << endl;
cout << "Numero de Passageiros: " << a.getNumPassageiros() << endl;
cout << "Velocidade: " << a.getVelocidadeAtual() << endl;
cout << "Altura inicial: " << a.getAltura() << endl;
a.subir(10);
cout << "Altura depois de subir: " << a.getAltura() << endl;
a.descer(318);
cout << "Altura depois de descer: " << a.getAltura() << endl << endl;


cout << "======================================" << endl << endl;


cout << "Balao" << endl;
cout << "Nome: " << b.getNome() << endl;
cout << "Numero de Passageiros: " << b.getNumPassageiros() << endl;
cout << "Velocidade: " << b.getVelocidadeAtual() << endl;
cout << "Altura inicial: " << b.getAltura() << endl;
b.subir(70);
cout << "Altura depois de subir: " << b.getAltura() << endl;
b.descer(384);
cout << "Altura depois de descer: " << b.getAltura() << endl << endl;

cout << "======================================" << endl << endl;

cout << "TESTE DA COMPARACAO USANDO FUNCAO AMIGA" << endl;
a > b;

    return 0;

}