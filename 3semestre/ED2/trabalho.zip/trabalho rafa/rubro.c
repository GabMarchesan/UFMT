#include <stdio.h>
#include <stdlib.h>
#include <time.h>

typedef enum { VERMELHO, PRETO } Cor;

typedef struct No {
    int chave;
    struct No *esquerda, *direita, *parente;
    Cor cor;
} No;

// Declarações de Função
No* criarNo(int chave);
void rotacaoEsquerda(No** raiz, No* x, int* rota);
void rotacaoDireita(No** raiz, No* y, int* rota);
void inserirFixup(No** raiz, No* no, int* rota);
void inserir(No** raiz, No* no, int* rota);
int altura(No* raiz);
void imprimirArvore(No* raiz, int espaco);
No* buscar(No* raiz, int chave, int* comparacoes);
void selecionarEBuscar(No* raiz, int* valores, int num_valores, int num_buscas);

No* criarNo(int chave) {
    No* no = (No*)malloc(sizeof(No));
    no->chave = chave;
    no->esquerda = no->direita = no->parente = NULL;
    no->cor = VERMELHO;
    return no;
}

void rotacaoEsquerda(No** raiz, No* x, int* rota) {
    No* y = x->direita;
    x->direita = y->esquerda;
    if (y->esquerda != NULL) y->esquerda->parente = x;
    y->parente = x->parente;
    if (x->parente == NULL) *raiz = y;
    else if (x == x->parente->esquerda) x->parente->esquerda = y;
    else x->parente->direita = y;
    y->esquerda = x;
    x->parente = y;
    (*rota)++;
}

void rotacaoDireita(No** raiz, No* y, int* rota) {
    No* x = y->esquerda;
    y->esquerda = x->direita;
    if (x->direita != NULL) x->direita->parente = y;
    x->parente = y->parente;
    if (y->parente == NULL) *raiz = x;
    else if (y == y->parente->direita) y->parente->direita = x;
    else y->parente->esquerda = x;
    x->direita = y;
    y->parente = x;
    (*rota)++;
}

void inserirFixup(No** raiz, No* no, int* rota) {
    No* tio;
    while (no->parente != NULL && no->parente->cor == VERMELHO) {
        if (no->parente == no->parente->parente->esquerda) {
            tio = no->parente->parente->direita;
            if (tio != NULL && tio->cor == VERMELHO) {
                no->parente->cor = PRETO;
                tio->cor = PRETO;
                no->parente->parente->cor = VERMELHO;
                no = no->parente->parente;
            } else {
                if (no == no->parente->direita) {
                    no = no->parente;
                    rotacaoEsquerda(raiz, no, rota);
                }
                no->parente->cor = PRETO;
                no->parente->parente->cor = VERMELHO;
                rotacaoDireita(raiz, no->parente->parente, rota);
            }
        } else {
            tio = no->parente->parente->esquerda;
            if (tio != NULL && tio->cor == VERMELHO) {
                no->parente->cor = PRETO;
                tio->cor = PRETO;
                no->parente->parente->cor = VERMELHO;
                no = no->parente->parente;
            } else {
                if (no == no->parente->esquerda) {
                    no = no->parente;
                    rotacaoDireita(raiz, no, rota);
                }
                no->parente->cor = PRETO;
                no->parente->parente->cor = VERMELHO;
                rotacaoEsquerda(raiz, no->parente->parente, rota);
            }
        }
    }
    (*raiz)->cor = PRETO;
}

void inserir(No** raiz, No* no, int* rota) {
    No* y = NULL;
    No* x = *raiz;

    while (x != NULL) {
        y = x;
        if (no->chave < x->chave)
            x = x->esquerda;
        else
            x = x->direita;
    }

    no->parente = y;
    if (y == NULL)
        *raiz = no;
    else if (no->chave < y->chave)
        y->esquerda = no;
    else
        y->direita = no;

    inserirFixup(raiz, no, rota);
}

int altura(No* raiz) {
    if (raiz == NULL)
        return 0;
    int altura_esquerda = altura(raiz->esquerda);
    int altura_direita = altura(raiz->direita);
    return (altura_esquerda > altura_direita ? altura_esquerda : altura_direita) + 1;
}

void imprimirArvore(No* raiz, int espaco) {
    if (raiz == NULL)
        return;

    espaco += 10;

    imprimirArvore(raiz->direita, espaco);

    printf("\n");
    for (int i = 10; i < espaco; i++)
        printf(" ");
    printf("%d", raiz->chave);
    if (raiz->cor == VERMELHO)
        printf("(R)\n");
    else
        printf("(P)\n");

    imprimirArvore(raiz->esquerda, espaco);
}

No* buscar(No* raiz, int chave, int* comparacoes) {
    while (raiz != NULL) {
        (*comparacoes)++;
        if (chave == raiz->chave)
            return raiz;
        if (chave < raiz->chave)
            raiz = raiz->esquerda;
        else
            raiz = raiz->direita;
    }
    return NULL;
}

void selecionarEBuscar(No* raiz, int* valores, int num_valores, int num_buscas) {
    srand(time(NULL));  // Inicializa o gerador de números aleatórios

    int *indices = (int*)malloc(num_buscas * sizeof(int));
    if (indices == NULL) {
        printf("Erro ao alocar memória para os índices.\n");
        return;
    }

    // Seleciona aleatoriamente os índices
    for (int i = 0; i < num_buscas; i++) {
        indices[i] = rand() % num_valores;
    }

    // Evita duplicatas nos índices
    for (int i = 0; i < num_buscas; i++) {
        for (int j = i + 1; j < num_buscas; j++) {
            if (indices[i] == indices[j]) {
                indices[j] = rand() % num_valores;
                j = i;
            }
        }
    }

    // Realiza a busca para cada valor selecionado e calcula o tempo e comparações
    for (int i = 0; i < num_buscas; i++) {
        int chave_busca = valores[indices[i]];
        int comparacoes = 0;
        clock_t inicio = clock();
        buscar(raiz, chave_busca, &comparacoes);
        clock_t fim = clock();
        double tempo_busca = ((double)(fim - inicio)) / CLOCKS_PER_SEC * 1000; // Convertendo segundos para milissegundos

        // Resultados da busca
        printf("Valor buscado: %d\n", chave_busca);
        printf("Tempo de busca: %f milissegundos\n", tempo_busca);
        printf("Número de comparações na busca: %d\n\n", comparacoes);
    }

    free(indices);
}

