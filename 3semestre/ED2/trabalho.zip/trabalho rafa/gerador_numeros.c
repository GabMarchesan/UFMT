#include <stdio.h>
#include <stdlib.h>
#include <time.h>

// Função para embaralhar um array
void embaralhar(int arr[], int n) {
    for (int i = n - 1; i > 0; --i) {
        int j = rand() % (i + 1);
        // Trocar arr[i] e arr[j]
        int temp = arr[i];
        arr[i] = arr[j];
        arr[j] = temp;
    }
}

// Função para gerar um arquivo com números aleatórios
void gerar_arquivo(const char *caminho_arquivo, int num_valores) {
    if (num_valores > 100000 || num_valores <= 0) {
        fprintf(stderr, "Número de valores deve estar entre 1 e 100.000.\n");
        exit(EXIT_FAILURE);
    }

    FILE *arquivo = fopen(caminho_arquivo, "w");
    if (arquivo == NULL) {
        perror("Erro ao abrir o arquivo");
        exit(EXIT_FAILURE);
    }
    printf("Arquivo %s aberto com sucesso.\n", caminho_arquivo);

    // Inicializar o gerador de números aleatórios
    srand((unsigned int)time(NULL));

    // Alocar memória para armazenar os valores
    int *valores = malloc(100000 * sizeof(int));
    if (valores == NULL) {
        perror("Erro de alocação de memória");
        fclose(arquivo);
        exit(EXIT_FAILURE);
    }

    // Preencher array com números únicos de 1 a 100.000
    for (int i = 0; i < 100000; ++i) {
        valores[i] = i + 1;
    }

    // Embaralhar os valores
    embaralhar(valores, 100000);

    // Escrever os primeiros num_valores valores no arquivo
    for (int i = 0; i < num_valores; ++i) {
        fprintf(arquivo, "%d\n", valores[i]);
    }

    // Liberar memória e fechar o arquivo
    free(valores);
    fclose(arquivo);
    printf("Arquivo %s gerado com %d valores.\n", caminho_arquivo, num_valores);
}

int main(int argc, char *argv[]) {
    if (argc != 3) {
        fprintf(stderr, "Uso: %s <número de valores> <nome do arquivo>\n", argv[0]);
        return EXIT_FAILURE;
    }

    int num_valores = atoi(argv[1]);
    const char *caminho_arquivo = argv[2];

    if (num_valores <= 0 || num_valores > 100000) {
        fprintf(stderr, "Número de valores deve estar entre 1 e 100.000.\n");
        return EXIT_FAILURE;
    }

    gerar_arquivo(caminho_arquivo, num_valores);
    return EXIT_SUCCESS;
}
