#include <stdio.h>
#include <stdlib.h>
#include <time.h>

typedef struct no {
    int valor;
    struct no *esquerdo, *direito;
    int altura;
} No;

int total_rotacoes = 0;
int total_comparacoes = 0;

// Função que cria um novo nó
No* novoNo(int x) {
    No *novo = malloc(sizeof(No));
    if(novo){
        novo->valor = x;
        novo->esquerdo = NULL;
        novo->direito = NULL;
        novo->altura = 0;
    }
    else {
        printf("\nERRO ao alocar nó em novoNo!\n");
    }
    return novo;
}

// Retorna o maior dentre dois valores
int maior(int a, int b) {
    return ( a > b) ? a : b;
}

// Retorna a altura de um nó ou 0 caso ele seja null
int alturaDoNo(No *no) {
    if (no == NULL) {
        return -1;
    } 
    return no->altura;
}

// Calcula e retorna o fator de balanceamento de um nó
int fatorDeBalanceamento(No *no) {
    if (no) {
        return (alturaDoNo(no->esquerdo) - alturaDoNo(no->direito));
    } else {
        return 0;
    }
}

// ---------- ROTAÇÕES ----------

// Função para a rotação à direita
No* rotacaoDireita(No *r) {
    No *y, *f;
    y = r->esquerdo;
    f = y->direito;

    y->direito = r;
    r->esquerdo = f;

    r->altura = maior(alturaDoNo(r->esquerdo), alturaDoNo(r->direito)) + 1;
    y->altura = maior(alturaDoNo(y->esquerdo), alturaDoNo(y->direito)) + 1;

    total_rotacoes++;
    return y;
}

// Função para a rotação à esquerda
No* rotacaoEsquerda(No *r) {
    No *y, *f;
    y = r->direito;
    f = y->esquerdo;

    y->esquerdo = r;
    r->direito = f;

    r->altura = maior(alturaDoNo(r->esquerdo), alturaDoNo(r->direito)) + 1;
    y->altura = maior(alturaDoNo(y->esquerdo), alturaDoNo(y->direito)) + 1;

    total_rotacoes++;
    return y;
}

// Função para a rotação dupla direita-esquerda
No* rotacaoDireitaEsquerda(No *r) {
    r->direito = rotacaoDireita(r->direito);
    return rotacaoEsquerda(r);
}

// Função para a rotação dupla esquerda-direita
No* rotacaoEsquerdaDireita(No *r) { 
    r->esquerdo = rotacaoEsquerda(r->esquerdo);
    return rotacaoDireita(r);
}

// Função para realizar o balanceamento da árvore após uma inserção ou remoção
No* balancear(No *raiz){
    int fb = fatorDeBalanceamento(raiz);

    // Rotação à esquerda
    if(fb < -1 && fatorDeBalanceamento(raiz->direito) <= 0){
        raiz = rotacaoEsquerda(raiz);
    }
    // Rotação à direita
    else if(fb > 1 && fatorDeBalanceamento(raiz->esquerdo) >= 0){
        raiz = rotacaoDireita(raiz);
    }
    // Rotação dupla à esquerda
    else if(fb > 1 && fatorDeBalanceamento(raiz->esquerdo) < 0){
        raiz = rotacaoEsquerdaDireita(raiz);
    }
    // Rotação dupla à direita
    else if(fb < -1 && fatorDeBalanceamento(raiz->direito) > 0){
        raiz = rotacaoDireitaEsquerda(raiz);
    }
    return raiz;
}

// Insere um novo nó na árvore
No* inserir(No *raiz, int x){
    if(raiz == NULL) { // árvore vazia
        return novoNo(x);
    } else { // inserção será à esquerda ou à direita
        if(x < raiz->valor){
            raiz->esquerdo = inserir(raiz->esquerdo, x);
        } else if(x > raiz->valor) {
            raiz->direito = inserir(raiz->direito, x);
        } else {
            printf("\nInserção não realizada! O elemento %d já existe!\n", x);
            return raiz;
        }
    }

    // Recalcula a altura de todos os nós entre a raiz e o novo nó inserido
    raiz->altura = maior(alturaDoNo(raiz->esquerdo), alturaDoNo(raiz->direito)) + 1;

    // Verifica a necessidade de rebalancear a árvore
    raiz = balancear(raiz);

    return raiz;
}

// Função para calcular a altura da árvore
int alturaArvore(No *raiz) {
    if (raiz == NULL) return 0;
    int esquerda = alturaArvore(raiz->esquerdo);
    int direita = alturaArvore(raiz->direito);
    return 1 + maior(esquerda, direita);
}

// Função de busca na árvore
No* buscar(No *raiz, int valor, int *comparacoes) {
    while (raiz != NULL) {
        (*comparacoes)++;
        if (valor < raiz->valor) {
            raiz = raiz->esquerdo;
        } else if (valor > raiz->valor) {
            raiz = raiz->direito;
        } else {
            return raiz;
        }
    }
    return NULL;
}

// Função para selecionar valores e buscar na árvore
void selecionarEBuscar(No *raiz, int *valores, int num_valores, int num_buscas) {
    srand(time(NULL));  // Inicializa o gerador de números aleatórios

    int *indices = (int*)malloc(num_buscas * sizeof(int));
    if (indices == NULL) {
        printf("Erro ao alocar memória para os índices.\n");
        return;
    }

    // Seleciona aleatoriamente os índices
    for (int i = 0; i < num_buscas; i++) {
        indices[i] = rand() % num_valores;
    }

    // Evita duplicatas nos índices
    for (int i = 0; i < num_buscas; i++) {
        for (int j = i + 1; j < num_buscas; j++) {
            if (indices[i] == indices[j]) {
                indices[j] = rand() % num_valores;
                j = i;
            }
        }
    }

   // Realiza a busca para cada valor selecionado e calcula o tempo e comparações
    for (int i = 0; i < num_buscas; i++) {
        int chave_busca = valores[indices[i]];
        int comparacoes = 0;
        clock_t inicio = clock();
        buscar(raiz, chave_busca, &comparacoes);
        clock_t fim = clock();
        double tempo_busca = ((double)(fim - inicio)) / CLOCKS_PER_SEC * 1000; // Convertendo segundos para milissegundos

        // Resultados da busca
        printf("Valor buscado: %d\n", chave_busca);
        printf("Tempo de busca: %f milissegundos\n", tempo_busca);
        printf("Número de comparações na busca: %d\n\n", comparacoes);
}


    free(indices);
}
