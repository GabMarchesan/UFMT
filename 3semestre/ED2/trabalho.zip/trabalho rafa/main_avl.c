#include <stdio.h>
#include <stdlib.h>
#include "avl.c"

int main(int argc, char *argv[]) {
    if (argc < 2) {
        printf("Uso: %s <arquivo de entrada>\n", argv[0]);
        return 1;
    }

    // Abrir arquivo
    FILE *file = fopen(argv[1], "r");
    if (file == NULL) {
        printf("Não foi possível abrir o arquivo %s\n", argv[1]);
        return 1;
    }

    // Contar número de valores
    int tamanho = 0;
    int valor;
    while (fscanf(file, "%d", &valor) != EOF) {
        tamanho++;
    }
    rewind(file);

    // Alocar memória para armazenar valores
    int *valores = (int*)malloc(tamanho * sizeof(int));
    if (valores == NULL) {
        printf("Erro ao alocar memória para os valores.\n");
        fclose(file);
        return 1;
    }

    // Ler valores do arquivo
    int i = 0;
    while (fscanf(file, "%d", &valor) != EOF) {
        valores[i++] = valor;
    }
    fclose(file);

    // Inserir valores na árvore
    No *raiz = NULL;
    for (i = 0; i < tamanho; i++) {
        raiz = inserir(raiz, valores[i]);
    }

    // Altura da árvore
    int alturaArvore = altura(raiz);
    printf("Altura da árvore: %d\n", alturaArvore);

    // Selecionar e buscar valores
    int num_buscas = (tamanho * 20) / 100; // Definindo um número de buscas
    printf("Buscando %d valores selecionados aleatoriamente:\n", num_buscas);
    selecionarEBuscar(raiz, valores, tamanho, num_buscas);

    // Limpar memória
    free(valores);
    return 0;
}
