#include <stdio.h>
#include <stdlib.h>
#include "rubro.c"

int main(int argc, char *argv[]) {
    if (argc < 2) {
        printf("Uso: %s <arquivo de entrada>\n", argv[0]);
        return 1;
    }

    // Abrir arquivo
    FILE *file = fopen(argv[1], "r");
    if (file == NULL) {
        printf("Não foi possível abrir o arquivo %s\n", argv[1]);
        return 1;
    }

    // Contar número de valores
    int tamanho = 0;
    int valor;
    while (fscanf(file, "%d", &valor) != EOF) {
        tamanho++;
    }
    rewind(file);

    // Alocar memória para armazenar valores
    int *valores = (int*)malloc(tamanho * sizeof(int));
    if (valores == NULL) {
        printf("Erro ao alocar memória para os valores.\n");
        return 1;
    }

    // Ler valores do arquivo
    int i = 0;
    while (fscanf(file, "%d", &valores[i]) != EOF) {
        i++;
    }
    fclose(file);

    // Construir árvore
    No* raiz = NULL;
    int rota = 0;
    for (int i = 0; i < tamanho; i++) {
        No* no = criarNo(valores[i]);
        inserir(&raiz, no, &rota);
    }

    // Imprimindo a árvore de forma visual
    printf("Árvore Red-Black:\n");
    imprimirArvore(raiz, 0);

    // Altura da árvore
    int altura_arvore = altura(raiz);
    printf("Altura da árvore: %d\n", altura_arvore);

    // Número de rotações
    printf("Número de rotações durante inserção: %d\n", rota);

    // Selecionar 20% dos valores e realizar as buscas
    int num_buscas = (tamanho * 20) / 100;
    printf("Buscando %d valores selecionados aleatoriamente:\n", num_buscas);
    selecionarEBuscar(raiz, valores, tamanho, num_buscas);

    // Liberação de memória
    free(valores);

    return 0;
}
