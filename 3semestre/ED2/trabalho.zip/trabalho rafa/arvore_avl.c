#include <stdio.h>
#include <stdlib.h>
#include <time.h>

typedef struct NoAVL {
    int valor;
    struct NoAVL* esquerdo;
    struct NoAVL* direito;
    int altura;
} NoAVL;

int rotacoes = 0;  // Variável global para contar rotações
int comparacoes = 0;  // Variável global para contar comparações

// Função que cria um novo nó
NoAVL* criarNoAVL(int valor) {
    NoAVL* novoNo = (NoAVL*)malloc(sizeof(NoAVL));
    if (novoNo) {
        novoNo->valor = valor;
        novoNo->esquerdo = NULL;
        novoNo->direito = NULL;
        novoNo->altura = 1;
    } else {
        printf("\nERRO ao alocar nó em criarNoAVL!\n");
    }
    return novoNo;
}

// Retorna o maior dentre dois valores
int max(int a, int b) {
    return (a > b) ? a : b;
}

// Retorna a altura de um nó ou 0 caso ele seja null
int altura(NoAVL* no) {
    return no ? no->altura : 0;
}

// Calcula e retorna o fator de balanceamento de um nó
int obterBalanceamento(NoAVL* no) {
    return no ? altura(no->esquerdo) - altura(no->direito) : 0;
}

// Função para a rotação à direita
NoAVL* rotacionarDireita(NoAVL* raiz) {
    NoAVL* novaRaiz = raiz->esquerdo;
    NoAVL* temp = novaRaiz->direito;

    novaRaiz->direito = raiz;
    raiz->esquerdo = temp;

    raiz->altura = max(altura(raiz->esquerdo), altura(raiz->direito)) + 1;
    novaRaiz->altura = max(altura(novaRaiz->esquerdo), altura(novaRaiz->direito)) + 1;

    rotacoes++;  // Incrementa o contador de rotações
    printf("Rotação à direita no nó: %d\n", raiz->valor);
    return novaRaiz;
}

// Função para a rotação à esquerda
NoAVL* rotacionarEsquerda(NoAVL* raiz) {
    NoAVL* novaRaiz = raiz->direito;
    NoAVL* temp = novaRaiz->esquerdo;

    novaRaiz->esquerdo = raiz;
    raiz->direito = temp;

    raiz->altura = max(altura(raiz->esquerdo), altura(raiz->direito)) + 1;
    novaRaiz->altura = max(altura(novaRaiz->esquerdo), altura(novaRaiz->direito)) + 1;

    rotacoes++;  // Incrementa o contador de rotações
    printf("Rotação à esquerda no nó: %d\n", raiz->valor);
    return novaRaiz;
}

// Função para a rotação dupla direita-esquerda
NoAVL* rotacaoDireitaEsquerda(NoAVL* raiz) {
    printf("Rotação dupla direita-esquerda no nó: %d\n", raiz->valor);
    raiz->direito = rotacionarDireita(raiz->direito);
    return rotacionarEsquerda(raiz);
}

// Função para a rotação dupla esquerda-direita
NoAVL* rotacaoEsquerdaDireita(NoAVL* raiz) {
    printf("Rotação dupla esquerda-direita no nó: %d\n", raiz->valor);
    raiz->esquerdo = rotacionarEsquerda(raiz->esquerdo);
    return rotacionarDireita(raiz);
}

// Função para realizar o balanceamento da árvore após uma inserção ou remoção
NoAVL* balancear(NoAVL* raiz) {
    int balanceamento = obterBalanceamento(raiz);

    // Rotação à esquerda
    if (balanceamento < -1 && obterBalanceamento(raiz->direito) <= 0) {
        return rotacionarEsquerda(raiz);
    }
    // Rotação à direita
    if (balanceamento > 1 && obterBalanceamento(raiz->esquerdo) >= 0) {
        return rotacionarDireita(raiz);
    }
    // Rotação dupla à esquerda
    if (balanceamento > 1 && obterBalanceamento(raiz->esquerdo) < 0) {
        return rotacaoEsquerdaDireita(raiz);
    }
    // Rotação dupla à direita
    if (balanceamento < -1 && obterBalanceamento(raiz->direito) > 0) {
        return rotacaoDireitaEsquerda(raiz);
    }

    return raiz;
}

// Insere um novo nó na árvore
NoAVL* inserir(NoAVL* raiz, int valor) {
    if (raiz == NULL) { // árvore vazia
        return criarNoAVL(valor);
    }

    if (valor < raiz->valor) {
        raiz->esquerdo = inserir(raiz->esquerdo, valor);
    } else if (valor > raiz->valor) {
        raiz->direito = inserir(raiz->direito, valor);
    } else {
        printf("\nInserção não realizada! O elemento %d já existe!\n", valor);
        return raiz;
    }

    raiz->altura = max(altura(raiz->esquerdo), altura(raiz->direito)) + 1;
    return balancear(raiz);
}

// Função de busca na árvore
NoAVL* buscar(NoAVL* raiz, int valor, int* comparacoes) {
    while (raiz != NULL) {
        (*comparacoes)++;
        if (valor < raiz->valor) {
            raiz = raiz->esquerdo;
        } else if (valor > raiz->valor) {
            raiz = raiz->direito;
        } else {
            return raiz;
        }
    }
    return NULL;
}

// Função para selecionar valores e buscar na árvore
void buscarAleatorios(NoAVL* raiz, int* valores, int num_valores, int num_buscas, double* tempoTotal, int* comparacoesTotal) {
    srand(time(NULL));  // Inicializa o gerador de números aleatórios

    int* indices = (int*)malloc(num_buscas * sizeof(int));
    if (indices == NULL) {
        printf("Erro ao alocar memória para os índices.\n");
        return;
    }

    // Seleciona aleatoriamente os índices
    for (int i = 0; i < num_buscas; i++) {
        indices[i] = rand() % num_valores;
    }

    // Evita duplicatas nos índices
    for (int i = 0; i < num_buscas; i++) {
        for (int j = i + 1; j < num_buscas; j++) {
            if (indices[i] == indices[j]) {
                indices[j] = rand() % num_valores;
                j = i;
            }
        }
    }

    *tempoTotal = 0.0;
    *comparacoesTotal = 0;

    // Realiza a busca para cada valor selecionado e calcula o tempo e comparações
    for (int i = 0; i < num_buscas; i++) {
        int chave_busca = valores[indices[i]];
        int comparacoes = 0;
        clock_t inicio = clock();
        buscar(raiz, chave_busca, &comparacoes);
        clock_t fim = clock();
        *tempoTotal += ((double)(fim - inicio)) / CLOCKS_PER_SEC;
        *comparacoesTotal += comparacoes;
    }

    free(indices);
}

// Função para calcular a altura da árvore
int alturaArvore(NoAVL* raiz) {
    if (raiz == NULL) return 0;
    int esquerda = alturaArvore(raiz->esquerdo);
    int direita = alturaArvore(raiz->direito);
    return 1 + max(esquerda, direita);
}

// Função para percorrer a árvore em ordem
void percorrerEmOrdem(NoAVL* raiz) {
    if (raiz != NULL) {
        percorrerEmOrdem(raiz->esquerdo);
        printf("%d ", raiz->valor);
        percorrerEmOrdem(raiz->direito);
    }
}

// Função para ler valores de um arquivo
void lerValoresDoArquivo(const char* nomeArquivo, int** valores, int* n) {
    FILE* arquivo = fopen(nomeArquivo, "r");
    if (arquivo == NULL) {
        perror("Erro ao abrir o arquivo");
        exit(EXIT_FAILURE);
    }

    int capacidade = 1000;
    *valores = (int*)malloc(capacidade * sizeof(int));
    *n = 0;

    int valor;
    while (fscanf(arquivo, "%d", &valor) != EOF) {
        if (*n >= capacidade) {
            capacidade *= 2;
            *valores = (int*)realloc(*valores, capacidade * sizeof(int));
        }
        (*valores)[(*n)++] = valor;
    }

    fclose(arquivo);
}

// Função principal
int main(int argc, char* argv[]) {
    if (argc != 2) {
        fprintf(stderr, "Uso: %s <nome do arquivo>\n", argv[0]);
        return EXIT_FAILURE;
    }

    const char* nomeArquivo = argv[1];
    NoAVL* raiz = NULL;

    int* valores;
    int n;
    lerValoresDoArquivo(nomeArquivo, &valores, &n);

    for (int i = 0; i < n; i++) {
        raiz = inserir(raiz, valores[i]);
    }

    double tempoTotal;
    int comparacoesTotal;
    buscarAleatorios(raiz, valores, n, n / 5, &tempoTotal, &comparacoesTotal);

    printf("Árvore AVL em ordem: ");
    percorrerEmOrdem(raiz);
    printf("\n");

    printf("Número total de rotações: %d\n", rotacoes);
    printf("Número total de comparações: %d\n", comparacoesTotal);
    printf("Tempo total de busca: %f segundos\n", tempoTotal);

    free(valores);
    return 0;
}
