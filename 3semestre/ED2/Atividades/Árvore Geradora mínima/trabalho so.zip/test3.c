#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <sys/stat.h>
#include <dirent.h>
#include <errno.h>

#define MAX_INPUT_SIZE 1024

// Função para verificar se um arquivo existe
int file_exists(const char *filename) {
    struct stat buffer;
    return (stat(filename, &buffer) == 0);
}

// Função para verificar se um arquivo C é mais recente que o binário correspondente
int is_c_file_newer(const char *c_file, const char *binary_file) {
    struct stat c_stat, binary_stat;

    if (stat(c_file, &c_stat) == -1) {
        return 0; // Falha ao obter informações sobre o arquivo C
    }

    if (stat(binary_file, &binary_stat) == -1) {
        return 1; // O arquivo binário não existe, então o arquivo C é mais recente
    }

    return c_stat.st_mtime > binary_stat.st_mtime;
}

// Função para compilar e executar um programa C
int compile_and_execute_c_program(const char *c_file) {
    char binary_file[MAX_INPUT_SIZE];
    snprintf(binary_file, sizeof(binary_file), "%s.out", c_file);

    // Verifique se o arquivo C é mais recente que o binário
    if (!is_c_file_newer(c_file, binary_file)) {
        // Execute o programa binário existente
        char *args[] = {binary_file, NULL};
        execv(binary_file, args);
        fprintf(stderr, "shell: Erro ao executar o binário %s: %s\n", binary_file, strerror(errno));
        return 0; // Falha ao executar o binário
    }

    // Compile o programa C
    pid_t pid = fork();

    if (pid == 0) {
        // Filho
        if (execlp("gcc", "gcc", c_file, "-o", binary_file, NULL) == -1) {
            fprintf(stderr, "shell: Erro na compilação do programa C: %s\n", strerror(errno));
            exit(EXIT_FAILURE);
        }
    } else if (pid > 0) {
        // Pai
        int status;
        waitpid(pid, &status, 0);

        if (WIFEXITED(status) && WEXITSTATUS(status) == 0) {
            // Compilação bem-sucedida, execute o programa
            char *args[] = {binary_file, NULL};
            execv(binary_file, args);
            fprintf(stderr, "shell: Erro ao executar o binário %s: %s\n", binary_file, strerror(errno));
            return 0; // Falha ao executar o binário
        } else {
            fprintf(stderr, "shell: Falha na compilação do programa C\n");
            return 0; // Falha na compilação
        }
    } else {
        fprintf(stderr, "shell: Erro na criação de um processo filho: %s\n", strerror(errno));
        return 0; // Falha na criação de um processo filho
    }
}

// Função para executar um comando externo
void execute_external_command(char **args, char **path_directories, int background) {
    pid_t pid = fork();

    if (pid == 0) {
        // Filho

        // Verifique se é um programa C e compile, se necessário
        if (strstr(args[0], ".c") != NULL) {
            if (compile_and_execute_c_program(args[0])) {
                // Compilação e execução bem-sucedidas
                exit(EXIT_SUCCESS);
            } else {
                fprintf(stderr, "shell: Erro ao compilar e/ou executar o programa C\n");
                exit(EXIT_FAILURE);
            }
        }

        // Tenta executar o comando em cada diretório no caminho
        for (int j = 0; path_directories[j] != NULL; j++) {
            char command_path[MAX_INPUT_SIZE];
            snprintf(command_path, sizeof(command_path), "%s/%s", path_directories[j], args[0]);

            if (file_exists(command_path) && access(command_path, X_OK) == 0) {
                // Comando encontrado neste diretório, execute-o
                execv(command_path, args);
                fprintf(stderr, "shell: Erro ao executar o comando %s: %s\n", args[0], strerror(errno));
            }
        }

        // Se o loop terminar, o comando não foi encontrado
        fprintf(stderr, "shell: comando não encontrado: %s\n", args[0]);
        exit(EXIT_FAILURE);
    } else if (pid > 0) {
        // Pai
        if (!background) {
            int status;
            waitpid(pid, &status, 0);
        }
    } else {
        fprintf(stderr, "shell: Erro na criação de um processo filho: %s\n", strerror(errno));
    }
}

// Função para executar comandos com pipes
void execute_piped_commands(char **commands, char **path_directories) {
    int pipe_fds[2];
    int in_fd = 0;

    while (*commands) {
        pipe(pipe_fds);

        if (fork() == 0) {
            // Filho
            dup2(in_fd, 0); // Redireciona a entrada do filho
            if (*(commands + 1)) {
                dup2(pipe_fds[1], 1); // Redireciona a saída para o próximo comando
            }
            close(pipe_fds[0]);

            execute_external_command(commands, path_directories, 0);
            exit(EXIT_FAILURE);
        } else {
            // Pai
            close(pipe_fds[1]);
            wait(NULL);
            close(in_fd);
            in_fd = pipe_fds[0];
            commands++;
        }
    }
}

int main() {
    char input[MAX_INPUT_SIZE];
    char *args[MAX_INPUT_SIZE / 2 + 1];
    int should_run = 1;

    // Verifique se a variável de ambiente CAMINHO está definida
    char *path_env = getenv("CAMINHO");
    char *path_directories[MAX_INPUT_SIZE / 2 + 1];
    int path_count = 0;

    // Analise a variável CAMINHO em diretórios
    if (path_env != NULL) {
        char *token = strtok(path_env, ":");
        while (token != NULL) {
            path_directories[path_count++] = token;
            token = strtok(NULL, ":");
        }
        path_directories[path_count] = NULL;
    }

    while (should_run) {
        printf("shell> ");
        fflush(stdout);

        // Leia a entrada do usuário
        if (fgets(input, MAX_INPUT_SIZE, stdin) == NULL) {
            break;
        }

        // Analise a entrada do usuário
        int background = 0;
        int pipe_count = 0;
        char *pipe_commands[MAX_INPUT_SIZE / 2 + 1];

        char *token = strtok(input, " \n");
        while (token != NULL) {
            args[0] = token;

            if (strcmp(args[0], "&") == 0) {
                background = 1;
            } else if (strcmp(args[0], "|") == 0) {
                args[0] = NULL;
                pipe_commands[pipe_count] = NULL;
                pipe_count++;
            } else {
                pipe_commands[pipe_count] = args[0];
                args++;
            }

            token = strtok(NULL, " \n");
        }

        // Executar comandos com pipes, se houver
        if (pipe_count > 0) {
            pipe_commands[pipe_count] = args[0];
            execute_piped_commands(pipe_commands, path_directories);
        } else {
            // Executar um comando único
            execute_external_command(args, path_directories, background);
        }
    }

    return 0;
}
