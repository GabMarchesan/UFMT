
/**
 *
 * UFMT - Ciencia da Computacao
 * 
 * ED1 - Prof. Ivairton
 * 
 * Aluno: Herrison Batista de Meneses Junior / Gabriel Gomes Marchesan
 * 
 * Data: 21/04/2023
 * 
 * 
 *  Métodos de Ordenação
 * 
 **/

//bibliotecas
#include <stdio.h>
#include <stdlib.h>
#include<time.h>
#include<stdbool.h>

//prototipo
void imprimeVetor(int*, int);
void read_int_of_file(const char*, int*);
bool in_arr(int vetor[], int, int);
int gera_aleatorio(int);
void cria_arquivo(int, char*);

void bubble_sort(int*, int);
void shell_sort(int*, int);
void insert_sort(int*, int);
void merge_sort(int*, int);
void merge_sort_Recursivo(int*, int);
void quick_sort(int*, int);
void quick_sort_Recursivo(int*, int , int);

long int TrocasQuick;
long int TrocasMerge;

void imprimeVetor(int *arr, int size){

    for(int i = 0; i<size; i++){
        printf("[%d] ", arr[i]);
    }

    printf("\n\n");
}

void read_int_of_file(const char *path, int *arr){
    FILE* file = fopen(path, "r");
    int i = -1, count = 0; 
    if(file == NULL){
        printf("erro ao abrir arquivo\n");
        return;
    }
    fscanf(file, "%d", &i); 
    while(!feof(file)){ 
        arr[count] = i; 
        fscanf(file, "%d", &i); 
        count++; 
    }
    fclose(file);
}

bool in_arr(int arr[], int size, int num){

    for (int i = 0; i < size; i++){
    if (arr[i] == num) {
      return true;
    }
  }
  return false;
}

int gera_aleatorio(int maximo){
    int number = ((rand() * rand()) % maximo);
    return number;
}

void cria_arquivo(int size, char* filename){

    int arr[size];
    int i, random;
    int j = size;
    int maximo = 999999;
    for (i = 0; i < j; i++){
        random = gera_aleatorio(maximo);
        if (in_arr(arr, i, random) == false){
            arr[i] = random;
        }else{
            i--;
        }
    }
    FILE *file;
    file = fopen(filename, "w");
    for (i = 0; i < size; i++){
        fprintf(file, "%d\n", arr[i]);
    }
    fclose(file);
}

void bubble_sort(int *arr, int size){

    clock_t inicio = clock();
    int troca, aux;
    unsigned long int Trocas = 0;

    do {
        troca = 0;
        for (int i = 0; i < size-1; i++){
            if (arr[i] > arr[i+1]){
                aux = arr[i];
                arr[i] = arr[i+1];
                arr[i+1] = aux;
                troca = 1;
                Trocas++;
            }
        }
    } while (troca);
    printf("Trocas = %lu\n", Trocas);
    clock_t fim = clock();
    printf("         Tempo = %f segundos!\n\n", (double)(fim - inicio) / CLOCKS_PER_SEC);
}
 
void shell_sort (int *arr, int size){
    clock_t inicio = clock();
    long int Trocas = 0;
    int i, aux;
    int salto = (int)size/2;

    while (salto > 1){
        for (i = 0; i+salto < size; i++){
            if(arr[i] > arr[i+salto]){
                aux = arr[i];
                arr[i] = arr[i+salto];
                arr[i+salto] = aux;
                Trocas ++;
            }
        }
        salto = (int) salto/2;
    }
    int troca;
    do {
        troca = 0;
        for (i = 0; i < size-1; i++){
            if (arr[i] > arr[i+1]){
                aux = arr[i];
                arr[i] = arr[i+1];
                arr[i+1] = aux;
                troca = 1;
                Trocas++;
            }
        }
    } while (troca); 
    printf("Trocas = %ld\n", Trocas);
    clock_t fim = clock();
    printf("         Tempo = %f segundos!\n\n", (double)(fim - inicio) / CLOCKS_PER_SEC);

}

void insert_sort (int *arr, int size){

    clock_t inicio = clock();
    int arrAux[size];
    int contArr = size;
    int contArrAux = 0;	
	int pos_vet, i;
    long int Trocas = 0;

    for(i=0; i<contArr; i++){
        pos_vet = contArrAux;
        while((pos_vet > 0) && (arr[i]<arrAux[pos_vet-1])){
            arrAux[pos_vet] = arrAux[pos_vet-1];
            pos_vet--;
            Trocas++;
        }
        arrAux[pos_vet] = arr[i];
        contArrAux++;
    }

    for (i = 0; i != size ; i++){
        arr[i] = arrAux[i];
    }

    printf("Trocas = %ld\n", Trocas);
    clock_t fim = clock();
    printf("         Tempo = %f segundos!\n\n", (double)(fim - inicio) / CLOCKS_PER_SEC);;
}

void merge_sort (int *arr, int size) {

    clock_t inicio = clock();

    TrocasMerge = 0;

    merge_sort_Recursivo(arr, size);

    printf("Trocas = %ld\n", TrocasMerge);
    clock_t fim = clock();
    printf("         Tempo = %f segundos!\n\n", (double)(fim - inicio) / CLOCKS_PER_SEC);;

}

void merge_sort_Recursivo(int arr[], int size){

    int i, j, half, *arrAux, pos_aux;
    if(size > 1){
        half = (int) size / 2;

        merge_sort_Recursivo(&arr[0], half); 
        merge_sort_Recursivo(&arr[half], size-half); 
        arrAux = (int*) malloc(sizeof(int)*size);
        i = 0;
        j = half;
        pos_aux = 0;
        while ((i < half) && (j < size)){
            if(arr[i] < arr[j]){
                arrAux[pos_aux++] = arr[i++];
            } else {
                arrAux[pos_aux++] = arr[j++];
                TrocasMerge++;
            }
        }
        while ( i < half){
            arrAux[pos_aux++] = arr[i++];
        }
        while ( j < size){
            arrAux[pos_aux++] = arr[j++];
        }
        for (i=0; i<size; i++){
            arr[i] = arrAux[i];
        }
        free(arrAux); 
    }
}

void quick_sort(int *arr, int size){

    clock_t inicio = clock();
    TrocasQuick = 0;

    quick_sort_Recursivo(arr, 0, size);

    printf("Trocas = %ld\n", TrocasQuick);
    clock_t fim = clock();
    printf("         Tempo = %f segundos!\n\n", (double)(fim - inicio) / CLOCKS_PER_SEC);;

}

void quick_sort_Recursivo(int *arr, int begin, int end){

    int i, j, half, pivo, aux;
    half = (int) (end- begin)/2;
    pivo = arr[half];
    i = begin;
    j = end;

    while (i<j){
        
        while (arr[i] < pivo){
            i++;
        }
        while (arr[j] > pivo){
            j--;
        }
        if (i < j) {
            aux = arr[i];
            arr[i] = arr[j];
            arr[j] = aux;
            TrocasQuick++;
        }
    }

    if (j-1 > begin) {
        quick_sort_Recursivo(arr, begin, j-1);
    }
    if (i+1 < end) {
        quick_sort_Recursivo(arr, i+1, end);
    }
}

int main(){

    srand(time(NULL));
    
    cria_arquivo(10, "1000-arq1.txt");
    cria_arquivo(1000, "1000-arq2.txt");
    cria_arquivo(1000, "1000-arq3.txt");
    cria_arquivo(1000, "1000-arq4.txt");
    cria_arquivo(1000, "1000-arq5.txt");

    cria_arquivo(10000, "10000-arq6.txt");
    cria_arquivo(10000, "10000-arq7.txt");
    cria_arquivo(10000, "10000-arq8.txt");
    cria_arquivo(10000, "10000-arq9.txt");
    cria_arquivo(10000, "10000-arq10.txt");

    cria_arquivo(100000, "100000-arq11.txt");
    cria_arquivo(100000, "100000-arq12.txt");
    cria_arquivo(100000, "100000-arq13.txt");
    cria_arquivo(100000, "100000-arq14.txt");
    cria_arquivo(100000, "100000-arq15.txt");
    
    int array_1[1000], array_2[1000], array_3[1000], array_4[1000], array_5[1000];
    read_int_of_file("1000-arq1.txt", array_1);
    read_int_of_file("1000-arq2.txt", array_2);
    read_int_of_file("1000-arq3.txt", array_3);
    read_int_of_file("1000-arq4.txt", array_4);
    read_int_of_file("1000-arq5.txt", array_5);

    int array_6[10000], array_7[10000], array_8[10000], array_9[10000], array_10[10000];
    read_int_of_file("10000-arq6.txt", array_6);
    read_int_of_file("10000-arq7.txt", array_7);
    read_int_of_file("10000-arq8.txt", array_8);
    read_int_of_file("10000-arq9.txt", array_9);
    read_int_of_file("10000-arq10.txt", array_10);

    int array_11[100000], array_12[100000], array_13[100000], array_14[100000], array_15[100000];
    read_int_of_file("100000-arq11.txt", array_11);
    read_int_of_file("100000-arq12.txt", array_12);
    read_int_of_file("100000-arq13.txt", array_13);
    read_int_of_file("100000-arq14.txt", array_14);
    read_int_of_file("100000-arq15.txt", array_15);

    printf("LISTA 1: "); bubble_sort(array_1, 1000); 
    printf("LISTA 2: "); bubble_sort(array_2, 1000);
    printf("LISTA 3: "); bubble_sort(array_3, 1000);
    printf("LISTA 4: "); bubble_sort(array_4, 1000);
    printf("LISTA 5: "); bubble_sort(array_5, 1000);
    printf("LISTA 6: "); bubble_sort(array_6, 10000);
    printf("LISTA 7: "); bubble_sort(array_7, 10000);
    printf("LISTA 8: "); bubble_sort(array_8, 10000);
    printf("LISTA 9: "); bubble_sort(array_9, 10000);
    printf("LISTA 10: "); bubble_sort(array_10, 10000);
    printf("LISTA 11: "); bubble_sort(array_11, 100000);
    printf("LISTA 12: "); bubble_sort(array_12, 100000);
    printf("LISTA 13: "); bubble_sort(array_13, 100000);
    printf("LISTA 14: "); bubble_sort(array_14, 100000);
    printf("LISTA 15: "); bubble_sort(array_15, 100000);
    
    /*printf("LISTA 1: "); shell_sort(array_1, 1000);
    printf("LISTA 2: "); shell_sort(array_2, 1000);
    printf("LISTA 3: "); shell_sort(array_3, 1000);
    printf("LISTA 4: "); shell_sort(array_4, 1000);
    printf("LISTA 5: "); shell_sort(array_5, 1000);
    printf("LISTA 6: "); shell_sort(array_6, 10000);
    printf("LISTA 7: "); shell_sort(array_7, 10000);
    printf("LISTA 8: "); shell_sort(array_8, 10000);
    printf("LISTA 9: "); shell_sort(array_9, 10000);
    printf("LISTA 10: "); shell_sort(array_10, 10000); 
    printf("LISTA 11: "); shell_sort(array_11, 100000);
    printf("LISTA 12: "); shell_sort(array_12, 100000);
    printf("LISTA 13: "); shell_sort(array_13, 100000);
    printf("LISTA 14: "); shell_sort(array_14, 100000);
    printf("LISTA 15: "); shell_sort(array_15, 100000);*/

    /*printf("LISTA 1: "); insert_sort(array_1, 1000);
    printf("LISTA 2: "); insert_sort(array_2, 1000);
    printf("LISTA 3: "); insert_sort(array_3, 1000);
    printf("LISTA 4: "); insert_sort(array_4, 1000);
    printf("LISTA 5: "); insert_sort(array_5, 1000);
    printf("LISTA 6: "); insert_sort(array_6, 10000);
    printf("LISTA 7: "); insert_sort(array_7, 10000);
    printf("LISTA 8: "); insert_sort(array_8, 10000);
    printf("LISTA 9: "); insert_sort(array_9, 10000);
    printf("LISTA 10: "); insert_sort(array_10, 10000);
    printf("LISTA 11: "); insert_sort(array_11, 100000);
    printf("LISTA 12: "); insert_sort(array_12, 100000);
    printf("LISTA 13: "); insert_sort(array_13, 100000);
    printf("LISTA 14: "); insert_sort(array_14, 100000);
    printf("LISTA 15: "); insert_sort(array_15, 100000);*/

    /*printf("LISTA 1: "); merge_sort(array_1, 1000);
    printf("LISTA 2: "); merge_sort(array_2, 1000);
    printf("LISTA 3: "); merge_sort(array_3, 1000);
    printf("LISTA 4: "); merge_sort(array_4, 1000);
    printf("LISTA 5: "); merge_sort(array_5, 1000);
    printf("LISTA 6: "); merge_sort(array_6, 10000);
    printf("LISTA 7: "); merge_sort(array_7, 10000);
    printf("LISTA 8: "); merge_sort(array_8, 10000);
    printf("LISTA 9: "); merge_sort(array_9, 10000);
    printf("LISTA 10: "); merge_sort(array_10, 10000);
    printf("LISTA 11: "); merge_sort(array_11, 1000);
    printf("LISTA 12: "); merge_sort(array_12, 1000);
    printf("LISTA 13: "); merge_sort(array_13, 1000);
    printf("LISTA 14: "); merge_sort(array_14, 1000);
    printf("LISTA 15: "); merge_sort(array_15, 1000);*/
    
    /*printf("LISTA 1: "); quick_sort(array_1, 1000);
    printf("LISTA 2: "); quick_sort(array_2, 1000);
    printf("LISTA 3: "); quick_sort(array_3, 1000);
    printf("LISTA 4: "); quick_sort(array_4, 1000);
    printf("LISTA 5: "); quick_sort(array_5, 1000);
    printf("LISTA 6: "); quick_sort(array_6, 10000);
    printf("LISTA 7: "); quick_sort(array_7, 10000);
    printf("LISTA 8: "); quick_sort(array_8, 10000);
    printf("LISTA 9: "); quick_sort(array_9, 10000);
    printf("LISTA 10: "); quick_sort(array_10, 10000);
    printf("LISTA 11: "); quick_sort(array_11, 100000);
    printf("LISTA 12: "); quick_sort(array_12, 100000);
    printf("LISTA 13: "); quick_sort(array_13, 100000);
    printf("LISTA 14: "); quick_sort(array_14, 100000);
    printf("LISTA 15: "); quick_sort(array_15, 100000);*/ 

}